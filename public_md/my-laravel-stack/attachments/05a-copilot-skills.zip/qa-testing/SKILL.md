---
name: qa-testing
description: "Apply this skill whenever testing, verifying, or QAing application flows. Activates for: Playwright spec writing, screenshot verification, headed/headless test runs, end-to-end visual checks, login/auth helpers in tests, browser-log inspection, database-state verification, perf traces, page-by-page sanity sweeps, and combined view + data verification recipes that pair Playwright (frontend reality) with Laravel Boost (backend reality)."
license: MIT
metadata:
  author: sam.cleaning
---

# QA Testing — Playwright + Laravel Boost

This skill is the QA harness for sam.cleaning. It pairs **Playwright** (what the browser actually renders) with **Laravel Boost MCP tools** (what the database actually contains) so a single check answers both "does it look right?" and "did it land in the DB?".

## When to activate

- User says "verify", "check the page", "screenshot", "does X render", "regression"
- Working on a Blade view or component and want to confirm it didn't break
- Suspecting a controller change affected a downstream view
- Need to walk through a flow (register → login → create job → see in list) without manual clicking
- Anything that needs the answer to both "view says X" and "DB says Y"

## When NOT to activate

- Writing the underlying feature code — use the relevant language/framework skill instead
- Modifying CI configuration — outside this skill's scope
- PHPUnit feature/unit tests — use `laravel-best-practices` testing rules

## Quick Reference

### 1. Playwright recipes → `rules/playwright.md`

- Config lives at [playwright.config.ts](../../../playwright.config.ts); baseURL `http://sam.localhost`
- Specs live in `tests/e2e/**/*.spec.ts` — **note: gitignored on release branches** (line 33 of `.gitignore`), so specs are local-only outside `feature/*` branches
- `loginAs(page, email)` helper for auth flows
- Screenshot path convention: `.docs/design-integration/screenshots/live/<name>.png`
- Local runs are **headed by default** (config shows the browser + `slowMo`; CI stays headless) — you'll see the windows open. `npm run test:e2e:ui` for the timeline scrub
- Pair with `console.log()` for debug output; add `--workers=4` to a local run if you'd rather not watch one window at a time

### 2. Laravel Boost MCP → `rules/boost.md`

- `database-query` for read-only SQL — e.g. "did the wizard submit insert a user?"
- `database-schema` before writing migrations or before crafting a query
- `browser-logs` after a Playwright run to inspect server-side log entries (only recent)
- `tinker --execute` for one-off PHP eval (model existence, factory state)
- Always use Boost over manual `mysql` / raw `php artisan tinker` when both work

### 3. Page-by-page flows → `rules/flows.md`

Route inventory with: URL, controller, view, layout, role, key data attributes for selectors, what to verify, common gotchas. Curated for the design-integration surface — full live route list at `php artisan route:list`.

### 4. Combined recipes → `rules/recipes.md`

- **Wizard happy path:** Playwright drives the wizard → Boost confirms the user/employer row inserted with the right relationships
- **Toast verification:** Playwright triggers session('error') → screenshot the clay toast → confirm flash key cleared
- **Auto-apply regression:** screenshot 5 known-good pages → diff against a frozen baseline
- **Perf budget:** Playwright captures FCP/DCL/load → fail the run if FCP > 1.5s

## Prerequisites for every run

1. **Dev server up.** `php artisan serve --port=8080` (background it). Verify with `curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8080/` — should return 200.
2. **Vite manifest, not hot.** If `public/hot` exists and `npm run dev` isn't running, the page can't find CSS/JS — delete `public/hot` to fall back to the built manifest, OR start `npm run dev`. The built manifest is in `public/build/manifest.json`.
3. **Build fresh after SCSS/JS changes.** `npm run build` — Vite emits to `public/build/` (intentionally tracked per `.gitignore` line 73-74, "commit for deployment without rebuilding").
4. **Auth fixtures.** Seeded test users: `employer{1..N}@test.local` / `password`, `employee{1..N}@test.local` / `password` (from `SimulatedPaymentsSeeder`). If `database-query SELECT email FROM users LIMIT 5` is empty, run the seeder.

## How to apply this skill

When the user asks to verify a flow:

1. **Identify the flow.** Look it up in `rules/flows.md` — find the route, view, and key selectors.
2. **Frame the question.** Is it visual ("does the layout look right?"), behavioural ("does the next button advance?"), or stateful ("did the form submit insert a row?")? Pick the appropriate recipe from `rules/recipes.md`.
3. **Write or extend a spec.** Specs live in `tests/e2e/`. Follow naming `debug-<purpose>.spec.ts` for ad-hoc verification, `<feature>.spec.ts` for permanent suite tests. Use the helpers from `rules/playwright.md`.
4. **Run.** `npx playwright test <name>.spec.ts --reporter=line` for quick output, `--reporter=list` when you need per-test detail. Use `-g "<grep>"` to scope.
5. **Verify the other side.** If the test mutated state, run a Boost `database-query` to confirm — and the reverse if the test asserted a render that depends on DB state.
6. **Show the user.** Read the screenshot PNG into the conversation so the user sees the result.

## Surfaces this skill knows about

The design-integration phase touched every visible surface; this skill's flows.md mirrors that scope:

- **Guest** — home, login, register (both roles), guest job create, static pages
- **Employer** — jobs index (clay-tabs), jobs create/show/edit, proposals, employees, payments, profile
- **Employee** — find jobs, my jobs, proposals (clay-tabs), payments, profile
- **Cross-cutting** — navbar gooey-pill (desktop), mobile-nav-header/footer, register-wizard, toast, PWA install prompt

Admin and Reviewer surfaces are out of scope (design integration §10).
