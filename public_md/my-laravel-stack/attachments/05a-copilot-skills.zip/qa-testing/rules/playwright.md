# Playwright recipes

Playwright is the browser-truth half of the QA pair. These are project-shaped recipes — the patterns shipped here already work against the live `http://localhost:8080` baseURL.

## Setup invariants

- **Config:** [playwright.config.ts](../../../playwright.config.ts). One project (`chromium`, Desktop Chrome), `fullyParallel`, `reporter: 'html'`, baseURL from `PLAYWRIGHT_BASE_URL || 'http://localhost:8080'`. **Local runs are headed by default** (`headless: false` + `slowMo: 300` + `workers: 1` so windows open one-at-a-time and stay watchable); CI (`process.env.CI`) stays headless. Override locally with `--workers=N`.
- **Spec directory:** `tests/e2e/`. Sub-folders are conventional, not required: `tests/e2e/auth/`, `tests/e2e/visual/`, `tests/e2e/employer/`, etc.
- **Screenshot output:** `.docs/design-integration/screenshots/live/<name>.png` for verification screenshots that we want to keep. Playwright's automatic on-failure screenshots go to `test-results/`.
- **CLI:** `npx playwright test [glob] [-g pattern] [--reporter=line|list|html] [--headed]`. `npm run test:e2e` is the convenience wrapper; `:headed` shows the browser, `:ui` opens the timeline scrub.

## Login helper (drop-in)

The app's seeded test users are `employer{N}@test.local` and `employee{N}@test.local` with password `password` (from `database/seeders/SimulatedPaymentsSeeder.php`). Standard login helper:

```ts
async function loginAs(page, email, password = 'password') {
  await page.goto('/login', { waitUntil: 'networkidle' });
  await page.fill('#email', email);
  await page.fill('#password', password);
  await Promise.all([
    page.waitForLoadState('networkidle'),
    page.click('button[type="submit"]'),
  ]);
}
```

After `loginAs`, Laravel sets the session cookie on the page's context. Use `page.context().storageState()` to capture for reuse, or just call `loginAs` in `beforeEach`.

## Screenshot helper

```ts
async function snap(page, name, opts: { full?: boolean } = {}) {
  await page.waitForTimeout(400); // settle for fonts + animations
  await page.screenshot({
    path: `.docs/design-integration/screenshots/live/${name}.png`,
    fullPage: opts.full !== false,
  });
}
```

Convention: prefix names by purpose:
- `p<N>-<flow>-desktop.png` for phase-N verification (1366×900)
- `p<N>-mobile-<flow>.png` for mobile (390×844)
- `<flow>-after.png` and `<flow>-before.png` for diff pairs

## Viewports

| Profile | Width × Height | When |
|---|---|---|
| Desktop default | 1366 × 900 | Standard desktop QA |
| Mobile iPhone-ish | 390 × 844 | Mobile-nav-header / mobile-nav-footer verification |
| Narrow phone | 360 × 740 | Stress-test long titles, clay-tabs badge hide rule (<576px) |
| Tablet | 768 × 1024 | The `>=768px` register-wizard sidebar reveal |

```ts
await page.setViewportSize({ width: 1366, height: 900 });
```

## Console + page-error capture

Quietly hides 404s that aren't your concern, surfaces real JS errors:

```ts
const errors: string[] = [];
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
page.on('console', (msg) => {
  if (msg.type() === 'error') errors.push(`console: ${msg.text()}`);
});
// ... actions ...
if (errors.length) console.log(`[${name}] errors:\n  ${errors.join('\n  ')}`);
```

## Perf trace

Cheap FCP / DCL / load capture without launching DevTools:

```ts
const metrics = await page.evaluate(() => {
  const paints = performance.getEntriesByType('paint');
  const nav = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
  return {
    FCP: paints.find((p) => p.name === 'first-contentful-paint')?.startTime,
    DCL: nav?.domContentLoadedEventEnd,
    load: nav?.loadEventEnd,
  };
});
```

For deeper traces (paint cost, layout thrash): use `page.tracing.start({ screenshots: true, snapshots: true })`, run actions, then `page.tracing.stop({ path: 'trace.zip' })`. Open with `npx playwright show-trace trace.zip`.

## Bootstrap modal control

Pages with Bootstrap modals (`<x-modal>`, `pwaInstallModal`) expose `window.bootstrap`. Open without clicking a trigger:

```ts
await page.evaluate(() => {
  const el = document.getElementById('pwaInstallModal');
  const m = new (window as any).bootstrap.Modal(el);
  m.show();
});
```

Useful for screenshotting modals that depend on browser-feature detection (the PWA modal's "chromium-install" block is hidden by JS unless the install prompt event fires — reveal it manually for visual QA).

## Data-attribute selectors (preferred)

Per `.github/instructions/javascript.instructions.md`, the app uses data attributes for JS hooks. Use them in Playwright too — they're stable across markup refactors:

| Attribute | Belongs to | Use |
|---|---|---|
| `[data-wizard]` | register pages | Multi-step form container |
| `[data-wizard-step="N"]` | wizard pages | Step section |
| `[data-wizard-next]`, `[data-wizard-prev]` | wizard pages | Nav buttons |
| `[data-wizard-progress-bar]` | wizard pages | Progress bar element |
| `[data-clay-tabs]` | jobs/proposals | Tab container |
| `[data-clay-tab="<key>"]` | jobs/proposals | Tab button |
| `[data-clay-tab-panel="<key>"]` | jobs/proposals | Panel container |
| `[data-nav-pill]` | layout/navigation | Desktop role nav wrapper |
| `[data-mobile-nav-footer]` | layout (auth) | Mobile bottom tab-bar |
| `[data-navbar-logout]` | layout (auth) | Logout submit |
| `[data-cursor-sparkle]` (body attr) | register | Cursor sparkle scope |
| `[data-sidebar-source]` / `[data-sidebar-offcanvas-target]` | M-4 mover | Sidebar content-mover (unused currently) |

Fall back to ID selectors only when data attributes don't exist (e.g. `#email`, `#password` on the login form).

## Anti-patterns

- **Don't `page.click('text=…')`** for primary action buttons — text changes with i18n. Use `[data-wizard-next]` or `button[type="submit"]`.
- **Don't `waitForTimeout` for navigation** — use `Promise.all([page.waitForLoadState('networkidle'), page.click(...)])` so the click and the wait race together.
- **Don't share state across tests via globals.** Use `test.describe.configure({ mode: 'serial' })` if order matters, otherwise each test should set up its own context.
- **Don't commit screenshots that are huge or environment-specific.** `.docs/design-integration/screenshots/live/` is tracked, `test-results/` is not (default Playwright behaviour).

## When the spec doesn't run

Most common causes, in order:
1. **`sam.localhost` isn't serving.** `curl http://sam.localhost/` — if it fails, `php artisan serve --host=sam.localhost --port=80` (background it).
2. **`public/hot` exists but Vite dev server isn't.** Delete `public/hot` to fall back to the built manifest, or run `npm run dev` in parallel.
3. **Built manifest stale.** `npm run build` after any SCSS/JS change.
4. **Browser not installed.** First-time setup needs `npx playwright install chromium`.
5. **Auth blocking.** A spec that visits an auth'd route without `loginAs` redirects to `/login` — assert against `page.url()` if you suspect this.
