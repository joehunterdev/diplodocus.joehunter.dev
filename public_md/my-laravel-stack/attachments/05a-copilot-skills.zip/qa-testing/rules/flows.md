# Page-by-page flow inventory

Curated to the design-integration surface. For the exhaustive route map run `php artisan route:list`.

Columns: **URL** is what you type into Playwright's `page.goto()`. **Layout** is which Blade layout wraps the view (drives nav/footer behaviour). **Key selectors** are the data attributes a Playwright spec should target. **Verify** is what to check; **Gotchas** are the traps.

**Design reference**: canonical mockup URLs are indexed in [`.docs/design-integration/design-mockup-links.md`](../../../.docs/design-integration/design-mockup-links.md). Look up by route name; don't paste URLs here so the index stays the single source of truth.

---

## Guest surface

### `/` — Home (welcome)
- **Route name:** `home` · **Controller:** closure in `routes/web.php:42` · **View:** `welcome.blade.php`
- **Layout:** `<x-guest-layout>` (since the P3 fix; previously a standalone HTML page)
- **Auth:** guest only; logged-in users are redirected to their role dashboard
- **Verify:** clay-theme body bg ambient gradient; navbar with logo + "Install App | Log In"; two role-pick buttons (Owner / Cleaner); footer dev-card present
- **Gotchas:** if you see the old white-bg layout, the conversion to `<x-guest-layout>` was reverted — check commit `e365f30`

### `/login` — Sign in
- **Route name:** `login` · **View:** `auth/login.blade.php`
- **Auth:** guest only
- **Key selectors:** `#email`, `#password`, `button[type="submit"]`
- **Verify:** form in a `.clay-card`; submit button is `.wizard-btn-submit` (clay teal-green gradient); failed login surfaces a clay toast in bottom-left
- **Gotchas:** session('error') from failed creds shows the clay toast — `<x-toast-notifications>` reads from session

### `/employer/register` — 4-step employer wizard
- **Route name:** `employer.register` · **Controller:** `EmployerRegisteredController@create` · **View:** `auth/employer/register.blade.php`
- **Auth:** guest only · **Layout:** `<x-guest-layout>` with cursor-sparkle opt-in (body has `data-cursor-sparkle`)
- **Steps:** Preferences (1) → Personal Details (2) → Company Details (3, skip-when-empty) → Terms & Submit (4)
- **Key selectors:**
  - `[data-wizard]` — form root
  - `[data-wizard-step="1..4"]` — step sections
  - `[data-wizard-next]`, `[data-wizard-prev]` — nav buttons
  - `[data-wizard-progress-bar]` — width = `step/total * 100%`
  - `[data-wizard-sidebar-step="1..4"]` — sidebar progress markers (gets `.active` / `.done`)
  - `[data-wizard-terms-gate]` — must be checked for step 4 submit to enable
  - `#first_name`, `#last_name`, `#email`, `#password`, `#password_confirmation` — `<x-personal-details>` inputs
- **Verify:** initial state — only step 1 has `.wizard-step--active`; progress bar at 25%; sidebar dot 1 is `.active`. Click Continue → step 2 visible, others hidden, progress 50%, sidebar dot 1 = `.done` + dot 2 = `.active`. Step 3 next button reads "Skip for now" until any company field has a value. Step 4 submit disabled until `[data-wizard-terms-gate]` is checked.
- **Boost check after submit:**
  ```sql
  SELECT id, email FROM users WHERE email = '<wizard-email>';
  SELECT * FROM employers WHERE user_id = <id from above>;
  ```
- **Gotchas:** preference chips depend on `TagCategory::where('slug','employee-types')` — if empty the foreach renders nothing (seed gap, not bug); register-wizard.spec.ts exists at `tests/e2e/auth/register-wizard.spec.ts`

### `/employee/register` — 3-step employee wizard
- **Route name:** `employee.register` · **Controller:** `EmployeeRegisteredController@create` · **View:** `auth/employee/register.blade.php`
- **Steps:** Preferences (1) → Personal Details (2, includes DOB) → Terms & Submit (3)
- **Key selectors:** same `[data-wizard*]` contract as employer above
- **Preference tags expected:** `availability` (checkboxes), `locations` (multi-select); plus a `pay` range slider with `min_pay`/`max_pay` hidden inputs

### `/guest/job/create` — Guest job posting form
- **Route name:** `guest.job.create` · **Controller:** `GuestJobController@create` · **View:** `jobs/guest/edit.blade.php`
- **Layout:** `<x-app-layout>` (works for guests too)
- **Verify:** three `.clay-card` sidebar panels (Availability, Address, Contact Person); main column has price-summary + job-form + Personal Details; `window.priceBuilderConfig` is set in the page (now via `@push('scripts')`, not raw inline)
- **Gotchas:** the existing `<x-sidebar-layout>` renders the sidebar twice for mobile-offcanvas — M-4 sidebar-mover isn't needed here

### `/about-us`, `/our-team`, `/careers`, `/help-center`, `/contact`, `/faq`, `/privacy-agreement`, `/terms-and-conditions`, `/cookie-policy`
- **Routes:** all `Route::view(...)` in `routes/web.php`
- **Layout:** `<x-guest-layout>` · **Views:** `static/*.blade.php`
- **Verify:** clay-theme body bg; content panels picked up clay via auto-apply rule on `.section-group.shadow-sm` / `.card.shadow-sm` / `.shadow-sm.bg-white`; footer dev-card renders
- **Gotchas:** these inherit clay treatment automatically — no per-page changes were made; if one looks wrong, the bug is probably in `_clay-theme.scss`'s auto-apply rule

---

## Authenticated employer surface

Login as `employer1@test.local` / `password`.

### `/employer/dashboard` → redirect → `/employer/jobs`
- Dashboard route is a one-line redirect (see `routes/employer-routes.php:15-18`)
- The `dashboard/employer.blade.php` view exists but is dead code (Tailwind classes, never reached)

### `/employer/jobs` — Jobs index with clay-tabs
- **Route name:** `employer.jobs.index` · **Controller:** `EmployerJobController@index` · **View:** `jobs/employer/index.blade.php`
- **Layout:** `<x-app-layout>` · **Auth:** Employer
- **Key selectors:**
  - `[data-clay-tabs]` — tab container, has `data-clay-active="active"` initially and `data-clay-tint-target="#jobs-card"`
  - `[data-clay-tab="active|completed|drafts|closed"]` — tab buttons
  - `[data-clay-tab-panel="active|completed|drafts|closed"]` — panel containers
  - `[data-clay-tab-slider]` — the animated white pill (CSS `transition: left ..., width ...`)
- **Verify:** four tabs render with counts (or no badge if count is 0); clicking a tab swaps `.active` between buttons and panels; the slider's `left` and `width` style change; the wrapping card picks up a `.tint-<key>` class
- **Gotchas:** filtered view (`?filter=draft`) renders a single clay-card with paginated rows, no tabs — the clay-tabs only show on the unfiltered overview

### `/employer/jobs/create` — Job create form
- **Route name:** `employer.jobs.create` · **Controller:** `EmployerJobController@create`
- **Layout:** `<x-app-layout>` · **View:** `jobs/employer/edit.blade.php` (shared with edit)
- **Verify:** clay-themed form, price builder visible, address autocomplete works (uses `address.js` module)

### `/employer/jobs/{id}` — Job detail
- **Route name:** `employer.jobs.show` · **Controller:** `EmployerJobController@show`
- **Layout:** `<x-app-layout>` · **View:** `jobs/employer/show.blade.php`
- **Status:** clay-theme inherits, but the internal price/commission breakdown panel hasn't been bespoke-restyled — auto-apply only
- **Boost check:** `SELECT * FROM jobs WHERE id = ?` to confirm data matches what's rendered

### `/employer/jobs/{id}/proposals` — Applicants list
- **Route name:** `employer.jobs.proposals` · **View:** `jobs/employer/proposals.blade.php`
- **Verify:** list of `<x-card-row-user>` entries per proposal; clay-theme inherits

### `/employer/payments` — Payments index
- **Route name:** `employer.payment.index` · **View:** `employer/payments/index.blade.php`
- **Verify:** payments table with clay-card wrapping
- **Boost check:** `SELECT id, status, amount FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 5`

### `/notifications` — Notifications index
- **Route name:** `notifications.index` · **View:** `<role>/notifications/index.blade.php`
- **Key selectors:** `.notification-bell` (in mobile-nav-header), `[data-notification-id]` (per row)
- **Verify:** unread count badge in navbar matches DB; swipe-to-mark-read works on mobile
- **Boost check:** `SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read = 0`

---

## Authenticated employee surface

Login as `employee1@test.local` / `password`.

### `/employee/home` — Find jobs / search
- **Route name:** `employee.home` · **Controller:** `EmployeeHomeController@index` · **View:** `home/employee/index.blade.php`
- **Layout:** `<x-app-layout>` · **Auth:** Employee
- **Verify:** sidebar with search-filter (clay-card), Quick Stats (clay-card), main column with `<x-section-group>` of job rows
- **Key selectors:** `[data-search-results]`, `[data-search-pagination]`, `[data-search-count]` — driven by `search-filter.js`
- **Boost check:** `SELECT COUNT(*) FROM jobs WHERE status = 'Active'` should match the Quick Stats total

### `/proposals` — Employee proposals (clay-tabs)
- **Route name:** `proposals.home` · **Controller:** `ProposalsController@index` · **View:** `proposals/index.blade.php`
- **Verify:** three-tab clay switcher (Active / Closed / Hired); each panel shows `<x-card-row-employee-job>` rows; sidebar has filter cards
- **Boost check:** `SELECT status, COUNT(*) FROM proposals WHERE user_id = ? GROUP BY status`

### `/employee/jobs` — My jobs (ongoing / previous)
- **Route name:** `employee.jobs.index` · **View:** `jobs/employee/index.blade.php`
- **Filter:** `?filter=ongoing|previous`
- **Verify:** sidebar filter cards, main column with grouped job rows
- **Auto-apply:** picks up clay treatment from `.section-group.shadow-sm` rule

### `/employee/payments` — Payments + payout account
- **Route name:** `employee.payment.index` · **View:** `employee/payments/index.blade.php`
- **Verify:** clay-card payments table; Stripe payout-account status panel; auto-apply handles clay treatment

---

## Cross-cutting surfaces

These render on multiple routes; verify once.

### Navbar gooey-pill (desktop, ≥992px)
- **Selectors:** `[data-nav-pill]` (the role-nav UL wrapper), `[data-nav-pill-slider]` (injected by navbar.js)
- **Verify:** slider snaps to the `.nav-link.active` on load and on resize; `document.fonts.ready` triggers a re-position when DM Sans finishes loading
- **Gotchas:** if the slider is at `left: 0; width: 0`, no active link was found — happens on routes that aren't in the role-nav (e.g. `/notifications` doesn't have a corresponding nav item)

### Mobile-nav-header + mobile-nav-footer (<992px)
- **Top:** `layouts/partials/mobile-nav-header.blade.php` — logo, greeting (auth), bell with unread count or Log In link (guest)
- **Bottom:** `layouts/partials/mobile-nav-footer.blade.php` — 5-tab role-aware bar with center FAB; `[data-mobile-nav-footer]` on `<nav>`; active-tab detected by `navbar.js` via pathname match against link `href`
- **Verify:** correct tab gets `.active` for the current path; FAB is a clay-gradient SVG circle with white plus or role-specific icon
- **Gotchas:** guests don't see the mobile-nav-footer (the partial early-returns if `!authUser`)

### Register wizard (M-2)
- See `/employer/register` and `/employee/register` rows above for selectors
- **JS module:** `resources/js/modules/register-wizard.js`
- **Mobile peeking-card UX:** deliberately skipped for v1 (DB-1 awaiting Eris). Steps slide-fade via `opacity/translateY`, not the mockup's stacked-card layout

### Toast notifications
- **Component:** `<x-toast-notifications>` in `layouts/app.blade.php` and `guest.blade.php`
- **Trigger:** any controller calling `->with('success'|'error'|'warning'|'info'|'status', $message)` or returning `back()->withErrors($errors)`
- **Verify:** clay-radius corners; 4px left accent in semantic color; sits bottom-left with auto-hide based on `config('alerts.types.{type}.delay')`

### PWA install prompt
- **Component:** `<x-pwa-install-prompt>` (modal id `pwaInstallModal`)
- **Trigger:** `data-bs-toggle="modal" data-bs-target="#pwaInstallModal"` on the navbar Install link, fired by `pwa-install.js` when `beforeinstallprompt` event arrived
- **Verify:** install button uses `.wizard-btn-submit` gradient; the Chromium/Firefox/Safari instruction blocks each show conditionally based on UA detection in the module

---

## Inertia React (out of scope)

`/employer/messages`, `/employee/messages`, `/admin/messages` use Inertia React via `layouts/inertia.blade.php`. The layout shell gets clay-theme but the React `MessagesPage` component isn't restyled (design integration §12).

If you need to QA messaging:
1. `loginAs` via Playwright (works the same — session is set)
2. `page.goto('/employer/messages')` — the shell loads
3. The page contents are React, so use React-friendly selectors (`role`, `aria-label`) rather than data attributes
