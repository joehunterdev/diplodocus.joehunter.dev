# Laravel Boost MCP for QA

Boost is the database-truth half of the pair. Once Playwright says "the wizard rendered the success state", Boost says "and here's the row that landed". Always prefer Boost over manual `mysql` or raw `tinker` when the answer is in the database, in browser logs, or in the route map.

Boost tools available in this project (MCP-provided):

- `database-query` — read-only SQL
- `database-schema` — inspect table structure
- `browser-logs` — recent browser-side log entries forwarded to Laravel
- `get-absolute-url` — resolve scheme + host + port for a route (use before sharing URLs)
- `search-docs` — version-specific framework docs
- Plus `tinker --execute` for one-off PHP eval

## database-query (read-only)

Use to verify state after a Playwright action mutated the DB, or to inspect the data a view is about to render.

```sql
-- Did the register wizard insert the user?
SELECT id, email, role, created_at FROM users
WHERE email = 'qa@example.test'
ORDER BY id DESC LIMIT 1;

-- Did the employer record attach correctly?
SELECT e.id, e.user_id, e.company_name, e.vat_number
FROM employers e
JOIN users u ON u.id = e.user_id
WHERE u.email = 'qa@example.test';

-- Job counts the employer/jobs/index renders
SELECT status, COUNT(*) FROM jobs
WHERE user_id = (SELECT id FROM users WHERE email = 'employer1@test.local')
GROUP BY status;
```

**Never** run write queries via Boost — it's read-only by design. Mutations come from Playwright actions or factory calls.

## database-schema before writing queries

Before crafting a query against a table you don't know cold, run `database-schema` first. Saves the rabbit hole of guessing column names. The schema dump includes column types, nullability, indexes, and FK constraints in one shot.

Common tables for QA:
- `users` — auth, role
- `employers` / `employees` — role-specific data
- `jobs` — employer's listings
- `proposals` — employee submissions on jobs
- `tags`, `tag_categories`, `taggables` — preference tags (the `employee-types` category is used by the register wizard)
- `notifications` — bell + footer count

## browser-logs after a Playwright run

The app forwards browser-side `console.log` and JS errors via the `console.logs.store` route → `ConsoleLogController`. Boost's `browser-logs` reads recent entries.

When to use: after a Playwright run failed in a non-obvious way, or when a screenshot looks wrong and you want to know if the page threw JS errors during render. Filter by recent timestamps; old entries lie.

When NOT to use: as a primary debug channel — Playwright's `page.on('pageerror', …)` is closer to ground truth because it captures errors that never made it to `console.log`.

## tinker --execute (one-off)

For PHP-side queries that aren't pure SQL — model accessors, scopes, computed properties.

```bash
php artisan tinker --execute 'echo App\Models\TagCategory::where("slug","employee-types")->first()?->tags()->count() ?? "none";'
```

- Always single-quote the outer command so the shell doesn't expand `$`.
- Use double-quotes inside for PHP strings.
- Avoid model factories in tinker — call factories from a real seeder or test instead.
- Don't create rows from tinker as part of QA. If you need test data, run a seeder.

## get-absolute-url before sharing URLs

When you're going to print a URL to the user, run `get-absolute-url` first so the scheme + port match how the app is actually exposed. Saves the user from clicking a `localhost:8000` link when the app is at `sam.localhost:80`.

## search-docs before guessing API syntax

When the QA touch point involves an unfamiliar Laravel feature (e.g. `Inertia::optional()`, queue middleware, mail markdown), `search-docs` returns version-pinned snippets. Faster than guessing and rebuilding.

## What Boost does NOT do

- Mutate the DB — read-only by design
- Replace Playwright — UI state is browser-truth, not DB-truth
- Replace PHPUnit feature tests — Boost is for ad-hoc inspection during a QA session, not a permanent regression suite

## Pairing pattern

When a QA task is "does X happen end-to-end?", split it:

| Step | Tool | Question |
|---|---|---|
| 1 | Playwright | Does the page render the expected initial state? |
| 2 | Playwright | Do the user actions complete without JS error? |
| 3 | Playwright | Does the post-action page render the expected final state? |
| 4 | Boost `database-query` | Does the DB reflect the action? |
| 5 | Boost `browser-logs` | Were there silent errors during the run? |

Steps 1–3 are inside the spec. Steps 4–5 are calls the agent makes after the spec returns. Don't try to invoke Boost from inside a Playwright spec — they're separate MCP layers.
