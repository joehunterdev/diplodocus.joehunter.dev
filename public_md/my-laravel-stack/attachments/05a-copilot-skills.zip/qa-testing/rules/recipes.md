# Combined recipes

Playwright drives the browser. Boost reads the database and forwarded logs. These recipes pair them so a single QA pass answers both halves.

The pattern is always:

1. Playwright sets up state via UI actions
2. Playwright asserts the rendered result
3. Boost confirms the DB / logs match
4. (optional) Screenshot the final state for the PR

---

## Recipe 1 — Wizard happy path with DB verification

**Goal:** confirm the employer register wizard inserts a `users` + `employers` row and attaches the right tags.

```ts
// tests/e2e/auth/register-wizard-e2e.spec.ts
import { test, expect } from '@playwright/test';

test('employer register end-to-end', async ({ page }) => {
  const stamp = Date.now();
  const email = `qa-${stamp}@test.invalid`;

  await page.goto('/employer/register');

  // Step 1 — preferences (skip)
  await page.click('[data-wizard-step="1"] [data-wizard-next]');

  // Step 2 — personal details
  await page.locator('#title').selectOption('Mr');
  await page.fill('#first_name', 'QA');
  await page.fill('#last_name', 'Tester');
  await page.fill('#email', email);
  await page.locator('[name="mobile"]').fill('+34612345678');
  await page.fill('#password', 'Passw0rd!');
  await page.fill('#password_confirmation', 'Passw0rd!');
  await page.click('[data-wizard-step="2"] [data-wizard-next]');

  // Step 3 — company (skip)
  await page.click('[data-wizard-step="3"] [data-wizard-next]');

  // Step 4 — terms gate
  const submit = page.locator('[data-wizard-submit]');
  await expect(submit).toBeDisabled();
  await page.check('[data-wizard-terms-gate]');
  await expect(submit).toBeEnabled();

  await Promise.all([
    page.waitForLoadState('networkidle'),
    submit.click(),
  ]);

  // Render assertion — we redirected away from the register page
  expect(page.url()).not.toContain('/employer/register');
});
```

Then in the agent layer (after the spec finishes):

```sql
-- Boost database-query
SELECT u.id, u.email, u.role, e.id AS employer_id, e.company_name
FROM users u
LEFT JOIN employers e ON e.user_id = u.id
WHERE u.email LIKE 'qa-%@test.invalid'
ORDER BY u.id DESC LIMIT 1;
```

Expected: one row, role='Employer', employer_id present, company_name NULL (skipped step). If you wanted the company step exercised, fill `#vat_number` / `#company_name` / `#trading_name` and re-check.

**Cleanup:** if your QA pipeline doesn't reset the DB, periodically:

```bash
php artisan tinker --execute 'App\Models\User::where("email", "like", "qa-%@test.invalid")->delete();'
```

---

## Recipe 2 — Toast verification

**Goal:** confirm a session('error') flash produces a clay-styled toast in the bottom-left corner.

```ts
test('failed login surfaces clay toast', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#email', 'noone@nowhere.invalid');
  await page.fill('#password', 'wrong');
  await Promise.all([
    page.waitForLoadState('networkidle'),
    page.click('button[type="submit"]'),
  ]);

  const toast = page.locator('.toast-container .alert-danger').first();
  await expect(toast).toBeVisible();

  // Visual confirmation
  await page.screenshot({
    path: '.docs/design-integration/screenshots/live/recipe-toast.png',
  });
});
```

Boost check (the session flash should be consumed after the page rendered):

```sql
-- sessions table records the user's session payload (depending on driver)
SELECT id, last_activity FROM sessions
WHERE user_id IS NULL ORDER BY last_activity DESC LIMIT 1;
```

If you're using `SESSION_DRIVER=file`, look in `storage/framework/sessions/`. The flash key gets cleared after one request — if it persists across reloads, the flash strategy is broken (see blade.instructions.md §2 "Never use session()->flash() for same-page renders").

---

## Recipe 3 — Visual regression sweep

**Goal:** screenshot a known-good set of pages and diff against a frozen baseline.

```ts
// tests/e2e/visual/regression.spec.ts
import { test } from '@playwright/test';

const pages = [
  { name: 'home',              url: '/' },
  { name: 'login',             url: '/login' },
  { name: 'employer-register', url: '/employer/register' },
  { name: 'employee-register', url: '/employee/register' },
  { name: 'guest-job-create',  url: '/guest/job/create' },
  { name: 'about',             url: '/about-us' },
];

for (const p of pages) {
  test(`regression ${p.name} desktop`, async ({ page }) => {
    await page.setViewportSize({ width: 1366, height: 900 });
    await page.goto(p.url, { waitUntil: 'networkidle' });
    await page.waitForTimeout(500);
    await page.screenshot({
      path: `.docs/design-integration/screenshots/live/regression-${p.name}-desktop.png`,
      fullPage: true,
    });
  });

  test(`regression ${p.name} mobile`, async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(p.url, { waitUntil: 'networkidle' });
    await page.waitForTimeout(500);
    await page.screenshot({
      path: `.docs/design-integration/screenshots/live/regression-${p.name}-mobile.png`,
      fullPage: true,
    });
  });
}
```

Diff the output PNGs against a baseline folder. Built-in option: Playwright's `toHaveScreenshot()` API with baselines stored alongside specs — but the baselines must be committed, and `tests/` is gitignored on release branches. So for now this is a manual eyeball comparison.

---

## Recipe 4 — Perf budget gate

**Goal:** fail the run if FCP exceeds 1500ms on a page known to have heavy clay shadows.

```ts
test('paint perf budget on /about-us', async ({ page }) => {
  await page.goto('/about-us', { waitUntil: 'networkidle' });

  const fcp = await page.evaluate(() => {
    const p = performance.getEntriesByType('paint').find((x) => x.name === 'first-contentful-paint');
    return p?.startTime ?? Infinity;
  });

  console.log(`[perf] FCP /about-us = ${fcp.toFixed(0)}ms`);
  expect(fcp).toBeLessThan(1500);
});
```

Current measurement (2026-05-18) was FCP ~756ms — plenty of headroom. If a future change drops this through the budget, you have an automated signal before users notice.

---

## Recipe 5 — Auto-apply rule regression check

**Goal:** confirm the `body.clay-theme .card.shadow-sm` / `.section-group.shadow-sm` / `.shadow-sm.bg-white` auto-apply rule is still upgrading legacy Bootstrap surfaces.

```ts
test('auto-apply clay treatment is active on /about-us', async ({ page }) => {
  await page.goto('/about-us');

  const styled = await page.evaluate(() => {
    const el = document.querySelector('.section-group.shadow-sm, .card.shadow-sm');
    if (!el) return null;
    const cs = getComputedStyle(el);
    return {
      bg: cs.backgroundColor,
      radius: cs.borderRadius,
      shadow: cs.boxShadow,
    };
  });

  expect(styled).not.toBeNull();
  expect(styled!.radius).toBe('22px'); // var(--clay-radius)
  expect(styled!.shadow).toContain('rgba(0, 0, 0, 0.11)'); // first stop of --clay-shadow-card
});
```

If this test goes red, the auto-apply rule in `_clay-theme.scss` was removed or overridden by a more specific selector. The fix is in that partial.

---

## Recipe 6 — Console + page-error capture during a flow

**Goal:** run a multi-step flow and dump any JS errors that appeared, so you don't ship a wizard that quietly throws in step 3.

```ts
test('wizard runs without JS errors', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`console: ${msg.text()}`);
  });

  await page.goto('/employer/register');
  await page.click('[data-wizard-step="1"] [data-wizard-next]');
  await page.fill('#first_name', 'A');
  await page.fill('#last_name', 'B');
  await page.click('[data-wizard-step="2"] [data-wizard-next]');
  await page.click('[data-wizard-step="3"] [data-wizard-next]');

  expect(errors).toEqual([]);
});
```

Optional Boost follow-up: `browser-logs` for anything the page forwarded to the server's console log endpoint (`POST /console-logs` → `ConsoleLogController@store`).

---

## When to write a recipe vs an ad-hoc spec

| Use case | Approach |
|---|---|
| One-off "does this still work?" check | Ad-hoc `tests/e2e/visual/debug-<thing>.spec.ts` with screenshots; throw it away |
| Verifying a fix before commit | Same as above, plus a Boost query if the fix touched DB shape |
| A known-failure-prone surface (wizard, clay-tabs) | Permanent spec in `tests/e2e/<feature>/` — survives gitignore on feature branches; on release branches, sync to a separate fixtures repo or pre-merge step |
| Visual-baseline diffing | Recipe 3 + a committed baseline folder; needs the `tests/` gitignore exemption |
| Perf gate | Recipe 4 in a permanent spec running in CI |

---

## Speed tips

- **Parallel runs** are on by default (`fullyParallel: true` in config). Don't `test.describe.configure({ mode: 'serial' })` unless tests share state.
- **Skip `waitUntil: 'networkidle'`** if the page has long-polling or chat sockets — use `'domcontentloaded'` + a specific `waitForSelector` instead.
- **Reuse auth state** with `page.context().storageState({ path: 'tests/.auth/employer.json' })` and `test.use({ storageState })` to skip login in every test.
- **Headed for the first run, headless after** — once you know what the page should look like, headless is 3-5× faster.
